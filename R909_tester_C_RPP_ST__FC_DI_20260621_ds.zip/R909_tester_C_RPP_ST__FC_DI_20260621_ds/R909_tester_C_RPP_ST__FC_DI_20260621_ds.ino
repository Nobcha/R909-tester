// ============================================================
// R909_tester_C_RPP_ST_FCNT_20260621.ino  v1.0 (2026.06.21)
//   導通テスト + Cメータ + 周波数カウンタ(PIO版) 統合
//   オリジナル：kpa radio by nobcha
//   改造：PIO周波数カウンタを非ブロッキング化してマージ
//    Raspberry Pi Picoでレシプロカル周波数カウンタを参照
//    https://ss1.xrea.com/harahore.g2.xrea.com/RaspberryPiPico/RPPicoRCounter.html
//   Diode judgement
// ============================================================
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "hardware/pio.h"
#include "freq_counter.pio.h"   // Place .h file in the same folder

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET     -1
#define SCREEN_ADDRESS 0x3C

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ★ Timing setting for FREQ counter
#define FREQ_GATE_MS   300   // Measing time(mS)
#define FREQ_HOLD_MS   500   // Holding time(mS)

// ==========================================
// PIN
// ==========================================
const int ENCODER_A  = 2;  // A
const int ENCODER_B  = 1;  // B
const int ENCODER_SW = 3;  // SW
const int ADC_PIN    = 26; // ADC (co ductio check)
const int BUZZER_PIN = 7;  // ブザー
const int TONE_PIN = 8;    // 1000Hz
const int CAP_CHARGE_PIN = 14; // Cメータ 充電制御
const int CAP_SENSE_PIN  = 27; // Cメータ 電圧読み取り (ADC)
const int PIN_FREQ_IN    = 15; // 周波数入力 (PIO用)

// Conduction meter
const float RREF = 10000.0; // 10kΩ プルアップ

// Capacitor meter
const float CAP_R = 100000.0; // 100kΩ
unsigned long lastMeasureTime;
#define MEASURE_INTERVAL 200

// ==========================================
// The structure must be set on top.
// ==========================================
struct Measurement {
  int adc_val;
  float Rp;
  float x;
};

// ==========================================
// Measurement data
// ==========================================
float capValue = -1.0;
int lastADC = 0;

// --- MENU mode  ---
enum Mode {
  MODE_CONT,    // 導通チェック
  MODE_C,       // キャパシタ
  MODE_DIODE,   // ダイオード（未実装）
  MODE_PARAM,   // パラメータ表示（導通用）
  MODE_PARAMC,  // パラメータ表示（C用）
  MODE_FREQ,    // ★ 周波数カウンタ (新規)
  MODE_COUNT
};
int currentMode = MODE_CONT;
int lastClkState;

// --- CAPACITANCE state  ---
enum CapState {
  CAP_IDLE,
  CAP_DISCHARGE,
  CAP_DISCHARGE_WAIT,
  CAP_CHARGE,
  CAP_CHARGE_WAIT,
  CAP_CALC,
  CAP_RESULT
};
CapState capState = CAP_IDLE;
unsigned long capTimer = 0;
unsigned long capStartTime = 0;
unsigned long capElapsed = 0;

// --- FREQUENCY COUNTER state (非ブロッキング) ---
enum FreqState {
  FREQ_IDLE,
  FREQ_START,
  FREQ_MEASURING,
  FREQ_DONE
};
FreqState freqState = FREQ_IDLE;
unsigned long freqGateMs = 1000;      // ゲート時間 (ミリ秒)
unsigned long freqStartTime = 0;
uint32_t freqResult = 0;              // 測定結果 (Hz)
PIO pio = pio0;
uint sm;
uint offset;

// --- prototyping ---
Measurement doMeasure();
void displayModeCont(float rx);
void displayModeC();
void displayModeDiode();
void displayModeParamCO(Measurement m);
float calculateTrueXBasedOnRealParameters(float rp);
float measureCapacitance();
void displayModeParamC();
void serviceCapMeter();
void displayModeFreq();               // ★ 周波数表示
void setup_pio();                     // ★ PIO初期化
void serviceFreqCounter();            // ★ 周波数カウンタ状態管理
uint32_t get_freq_result();           // ★ 結果取得 (ブロッキングなし)

// ==========================================
// setup()
// ==========================================
void setup() {
  Wire.setSDA(4);
  Wire.setSCL(5);
  Wire.begin();

  analogReadResolution(12);

  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);
  pinMode(ENCODER_SW, INPUT_PULLUP);
  pinMode(ADC_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  pinMode(CAP_CHARGE_PIN, OUTPUT);
  digitalWrite(CAP_CHARGE_PIN, LOW);
  pinMode(CAP_SENSE_PIN, INPUT);

  lastClkState = digitalRead(ENCODER_A);

  // ★ PIO 周波数カウンタ初期化
  setup_pio();

  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    for(;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("R909-TESTER v1.0");
  display.display();
  delay(1000);

  // ★ Test signal generation（GP16 is 1kHz）
  tone(8, 1000);
}

// ==========================================
// loop()
// ==========================================
void loop() {
  int clkState = digitalRead(ENCODER_A);

  // ★ 各サービスを定期的に呼び出す
  serviceCapMeter();
  serviceFreqCounter();   // ★ 周波数カウンタ状態管理

  // エンコーダ処理
  if (clkState == LOW && lastClkState == HIGH) {
    if (digitalRead(ENCODER_B) != clkState) {
      currentMode++;
      if (currentMode >= MODE_COUNT) currentMode = 0;
    } else {
      currentMode--;
      if (currentMode < 0) currentMode = MODE_COUNT - 1;
    }
    // ★ 周波数モードに切り替わったら計測をリセット
    if (currentMode == MODE_FREQ) {
      freqState = FREQ_IDLE;   // 次のループで再開
    }
  }
  lastClkState = clkState;

  // モード変更時のCメータ状態リセット（既存ロジック）
  static int oldMode = -1;
  if(oldMode != currentMode) {
    bool oldCapMode = (oldMode == MODE_C || oldMode == MODE_PARAMC);
    bool newCapMode = (currentMode == MODE_C || currentMode == MODE_PARAMC);
    if(!oldCapMode && newCapMode) {
      capState = CAP_DISCHARGE;
    }
    if(oldCapMode && !newCapMode) {
      capState = CAP_IDLE;
    }
    oldMode = currentMode;
  }

  // Display ever 200ms
  unsigned long currentTime = millis();
  if (currentTime - lastMeasureTime >= MEASURE_INTERVAL) {
    lastMeasureTime = currentTime;

    noTone(BUZZER_PIN);
    Measurement m = doMeasure();   // For conduction check (Reading constantly)

    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);

    switch (currentMode) {
      case MODE_CONT:    displayModeCont(m.x);    break;
      case MODE_PARAM:   displayModeParamCO(m);   break;
      case MODE_C:       displayModeC();          break;
      case MODE_PARAMC:  displayModeParamC();     break;
      case MODE_DIODE:   displayModeDiode();      break;
      case MODE_FREQ:    displayModeFreq();       break;   // ★
    }

    static uint32_t dispTimer = 0;
    if(millis() - dispTimer > 400) {
      dispTimer = millis();
      display.display();
    }
  }
}

// ==========================================
// Condution check 
// ==========================================
Measurement doMeasure() {
  Measurement m;
  uint32_t sum = 0;
  for(int i=0; i<4; i++) {
    sum += analogRead(ADC_PIN);
  }
  m.adc_val = sum / 4;
  if (m.adc_val < 5) {
    m.Rp = 0.0; m.x = 0.0; return m;
  }
  if (m.adc_val > 4090) {
    m.Rp = -1.0; m.x = -1.0; return m;
  }
  m.Rp = (float)m.adc_val * RREF / (4095.0 - (float)m.adc_val);
  m.x = calculateTrueXBasedOnRealParameters(m.Rp);
  return m;
}

void displayModeCont(float rx) {
  display.setTextSize(1);  display.setCursor(0,0);  display.print("[ MODE SELECT ]");
  display.setTextSize(2);  display.setCursor(0,18); display.println("1.CONT CHK");
  display.setCursor(32,36); display.setTextSize(3);
  int current_adc = analogRead(ADC_PIN);
  if (current_adc >= 0 && current_adc < 30) {
    display.println("SHORT");
    tone(BUZZER_PIN, 2000 + 10 * current_adc);
  } else {
    display.println("OPEN");
    noTone(BUZZER_PIN);
  }
}

float calculateTrueXBasedOnRealParameters(float rp) {
  if (rp < 1000.0 && rp >= 0) return (1000.0 * rp) / (1000.0 - rp);
  return -1.0;
}

void displayModeParamCO(Measurement m) {
  display.setTextSize(1);
  display.setCursor(0,0); display.print("[4.PARAMETER MONITOR]");
  display.setCursor(0,15); display.print("RAW ADC: "); display.println(m.adc_val);
  display.setCursor(0,26); display.print("V(pin) : "); display.print((float)m.adc_val * 3.3 / 4095.0, 2); display.println(" V");
  display.setCursor(0,33); display.print("Calc Rp: ");
  if(m.Rp < 0) display.println("OVER/OPEN"); else { display.print(m.Rp,1); display.println(" Ohm"); }
  display.setCursor(0,47); display.print("True X  : ");
  if(m.x < 0) display.println("OPEN"); else { display.print(m.x,1); display.println(" Ohm"); }
}

// ==========================================
// C meter
// ==========================================
void displayModeC() {
  display.setTextSize(1); display.setCursor(0,0); display.println("[ MODE SELECT ]");
  display.setTextSize(1); display.setCursor(0,18); display.println("2.CAPACITOR");
  display.setTextSize(2); display.setCursor(0,42);
  if(capValue < 0) { display.println("OPEN"); return; }
  if(capValue < 1e-9) { display.print(capValue * 1e12,1); display.print(" pF"); }
  else if(capValue < 1e-6) { display.print(capValue * 1e9,1); display.print(" nF"); }
  else { display.print(capValue * 1e6,2); display.print(" uF"); }
}

void displayModeParamC() {
  display.setTextSize(1);
  display.setCursor(0,0); display.print("[5.C PARAMETER MON]");
  display.setCursor(0,15); display.print("STATE="); display.println((int)capState);
  display.setCursor(0,26); display.print("ADC="); display.println(lastADC);
  display.setCursor(0,37); display.print("ELAPSED="); display.println(capElapsed);
  display.print("CAP="); display.println(capValue,9);
}

void displayModeDiode() {
  display.setTextSize(1); display.setCursor(0,0); display.print("[ MODE SELECT ]");
  display.setTextSize(1); display.setCursor(0,12); display.println("3.DIODE");

  float vf = measureDiodeVf();
  String type = diodeType(vf);

  display.setTextSize(2);
  display.setCursor(0,24);
  display.println(type);

  display.setTextSize(1);
  display.setCursor(0,40);
  display.printf("Vf=%.2fV", vf);

  display.display();
}

void serviceCapMeter() {
  switch(capState) {
    case CAP_IDLE: break;
    case CAP_DISCHARGE:
      digitalWrite(CAP_CHARGE_PIN, LOW);
      capTimer = millis();
      capState = CAP_DISCHARGE_WAIT;
      break;
    case CAP_DISCHARGE_WAIT:
      if(millis() - capTimer > 100) capState = CAP_CHARGE;
      break;
    case CAP_CHARGE:
      digitalWrite(CAP_CHARGE_PIN, HIGH);
      capStartTime = micros();
      capState = CAP_CHARGE_WAIT;
      break;
    case CAP_CHARGE_WAIT:
      lastADC = analogRead(CAP_SENSE_PIN);
      if(lastADC >= 2588) {
        capElapsed = micros() - capStartTime;
        digitalWrite(CAP_CHARGE_PIN, LOW);
        capState = CAP_CALC;
      } else if((micros() - capStartTime) > 3000000UL) {
        capValue = -1.0;
        digitalWrite(CAP_CHARGE_PIN, LOW);
        capState = CAP_RESULT;
      }
      break;
    case CAP_CALC:
      capValue = ((float)capElapsed * 1.0e-6f) / 100000.0f;
      capTimer = millis();
      capState = CAP_RESULT;
      break;
    case CAP_RESULT:
      if(millis() - capTimer > 1000) capState = CAP_DISCHARGE;
      break;
  }
}

// ==========================================
// ★ Frequency counter (PIO version)
// Diverted from below blog
// https://ss1.xrea.com/harahore.g2.xrea.com/RaspberryPiPico/RPPicoRCounter.html
// ==========================================
void setup_pio() {
  offset = pio_add_program(pio, &freq_counter_program);
  sm = pio_claim_unused_sm(pio, true);
  pio_sm_config c = freq_counter_program_get_default_config(offset);
  sm_config_set_in_pins(&c, PIN_FREQ_IN);
  sm_config_set_clkdiv(&c, 1.0);  // システムクロックそのまま

  pio_gpio_init(pio, PIN_FREQ_IN);
  gpio_set_pulls(PIN_FREQ_IN, false, true);  // pulling up
  pio_sm_init(pio, sm, offset, &c);

  // Initial condition : stopped
  pio_sm_set_enabled(pio, sm, false);
  freqState = FREQ_IDLE;
  freqResult = 0;
}

//
// Re design for display sequence 2026.06.19
void serviceFreqCounter() {
  if (currentMode != MODE_FREQ) {
    if (freqState != FREQ_IDLE) {
      pio_sm_set_enabled(pio, sm, false);
      freqState = FREQ_IDLE;
    }
    return;
  }

  switch (freqState) {
    case FREQ_IDLE:
      pio_sm_set_enabled(pio, sm, false);
      pio_sm_restart(pio, sm);
      pio_sm_clear_fifos(pio, sm);
      pio_sm_exec(pio, sm, 0xe020);   // set x, 0
      pio_sm_exec(pio, sm, 0xa049);   // mov x, !x
      pio_sm_exec(pio, sm, pio_encode_jmp(offset + 1));
      pio_sm_set_enabled(pio, sm, true);
      freqStartTime = millis();
      freqState = FREQ_MEASURING;
      break;

    case FREQ_MEASURING:
      if (millis() - freqStartTime >= FREQ_GATE_MS) {  // ★ constant
        pio_sm_set_enabled(pio, sm, false);
        pio_sm_exec(pio, sm, 0xa0c1);   // mov isr, x
        pio_sm_exec(pio, sm, 0x8020);   // push block
        uint32_t remaining = pio_sm_get_blocking(pio, sm);
        uint32_t count = 0xFFFFFFFF - remaining;
        unsigned long elapsed = millis() - freqStartTime;
        if (elapsed > 0) {
          freqResult = (uint32_t)((uint64_t)count * 1000 / elapsed);
        } else {
          freqResult = 0;
        }
        freqState = FREQ_DONE;
        freqStartTime = millis();  // For holding time of display
      }
      break;

    case FREQ_DONE:
      if (millis() - freqStartTime >= FREQ_HOLD_MS) {  // ★ constant
        freqState = FREQ_IDLE;
      }
      break;
  }
}

//
//  
void displayModeFreq() {
  display.setTextSize(1); display.setCursor(0,0); display.println("[ MODE SELECT ]");
  display.setTextSize(1); display.setCursor(0,18); display.println("6.FREQ COUNTER");
  
  // ★ The frequency (The previous value is holding.)
  display.setTextSize(2); display.setCursor(0,38);
  display.print(freqResult);
  display.print(" Hz");

  // ★ The small characters are showing status.
  display.setTextSize(1);
  display.setCursor(0, 56);
  if (freqState == FREQ_MEASURING) {
    display.print("STATUS: MEASURING...");
  } else if (freqState == FREQ_DONE) {
    display.print("STATUS: DONE       ");
  } else {
    display.print("STATUS: READY      ");
  }
}

// ===============================
// DIODE TEST
// GPIO14 ----100kΩ---->|---- GND
//                    |
//                 GPIO27(ADC)
// ===============================

#define DIODE_DRIVE_PIN 14
#define DIODE_ADC_PIN   27

float measureDiodeVf() {
    digitalWrite(DIODE_DRIVE_PIN, HIGH);
    delay(10);

    uint32_t sum = 0;

    for (int i = 0; i < 16; i++) {
        sum += analogRead(DIODE_ADC_PIN);
        delay(1);
    }

    digitalWrite(DIODE_DRIVE_PIN, LOW);

    float adc = sum / 16.0f;

    // RP2040 ADC 12bit
    float vf = adc * 3.3f / 4095.0f;

    return vf;
}

String diodeType(float vf) {
    if (vf < 0.05)
        return "SHORT";

    if (vf < 0.35)
        return "SCH/GE";

    if (vf < 0.90)
        return "SI DIODE";

    if (vf < 2.00)
        return "RED LED";

    if (vf < 2.50)
        return "GREEN LED";

    if (vf < 3.20)
        return "BLUE/WHT";

    return "OPEN";
}
