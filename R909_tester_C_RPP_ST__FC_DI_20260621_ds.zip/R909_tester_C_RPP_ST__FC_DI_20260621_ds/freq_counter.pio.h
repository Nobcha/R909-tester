#pragma once //                  ;  2026.02.16 ok
#include "hardware/pio.h"

static const uint16_t freq_counter_program_instructions[] = {
    0xa049, //  0: mov x, !x     ; Work once at first for setting as 1 on every bit of X
            //  loop:
    0x2020, //  1: wait 0 pin 0  ; Wait Low
    0x20a0, //  2: wait 1 pin 0  ; Wait High
    0x0041, //  3: jmp x-- 1     ; Count up and go to loop(1)
};

static const struct pio_program freq_counter_program = {
    .instructions = freq_counter_program_instructions,
    .length = 4,
    .origin = -1,
};

static inline pio_sm_config freq_counter_program_get_default_config(uint offset) {
    pio_sm_config c = pio_get_default_sm_config();
    // 0th command is for initilizing and let 1〜3 th to loop
    sm_config_set_wrap(&c, offset + 1, offset + 3);
    return c;
}